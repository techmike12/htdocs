<div>&copy; PHP Motors, All rights reserved.</div>
<span> All images used are believed to be in "Fair Use". Please notify the author if any are no and they will be removed</span>
<span id="modified"></span>