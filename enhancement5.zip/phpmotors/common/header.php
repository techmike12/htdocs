    <img id="logo" src="/phpmotors/images/site/logo.png" alt="PHP Logo">
    <a id="account" href="/phpmotors/accounts/index.php?action=login">My Account</a>